//
// Created by ikryxxdev on 10/22/25.
//

#ifndef IKSTR_IKSTR_ALLOC_H
#define IKSTR_IKSTR_ALLOC_H

#define iks_malloc malloc
#define iks_realloc realloc
#define iks_free free

#endif //IKSTR_IKSTR_ALLOC_H